
class GameEngine:
    def __init__(self):
        self.some_variable = None
    
    # Define your functions here